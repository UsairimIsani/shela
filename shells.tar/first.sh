# read -a names 
# cho=("$@")
# echo ${names[0]} ${names[2]} ${names[1]} 
# echo ${cho[0]} ${cho[2]} ${cho[1]}


#making aliases in bash lets seee

echo 'alias ce="code-insiders ."' >> ~/.bash_aliases



