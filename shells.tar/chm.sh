chmod 300 usairim.txt
ls -l
