args=("$@")
echo "alias ${args[0]}='code-insiders ${args[1]}'" >> ~/.bash_aliases