rm shells.tar

tar cvf shells.tar *.sh

ls -l 

read -t 2

rm *.sh

read -t 2

ls -l 

read -t 2

tar xvf shells.tar
